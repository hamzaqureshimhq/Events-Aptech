import { useState } from "react";
import  Table from './ShowMarks';

function TextBox(){
    var[eng,setEng] = useState(0);
    var[math,setMath] = useState(0);
    var[urdu,setUrdu] = useState(0);
    var[total,setTotal] = useState(0);
    var[perc,setPerc] = useState(0);

    function Calculator(jama){
        jama.preventDefault();
        total = parseFloat(eng) + parseFloat(urdu) + parseFloat(math);
        setTotal(total);

        perc = total/3;
        setPerc(perc);

        console.log(total + " " + perc);
    }

    return( 
    
         <div className="container">
            <form action="" method="post" onSubmit={Calculator} >

              <p style={{color:"blue"}} > Enter English Marks</p>
               <input type="number" className="form-control" value={eng} onChange={(a)=> {setEng(a.target.value)}} />

               <p  style={{color:"blue"}} >Enter Urdu Marks</p>
               <input type="number" className="form-control" value={urdu} onChange={(a)=> {setUrdu(a.target.value)}} />

               <p   style={{color:"blue"}}>Enter Math Marks</p>
               <input type="number" className="form-control" value={math} onChange={(a)=> {setMath(a.target.value)}} />
               <br />

               <button type="submit" className="btn btn-primary" >Calculator</button> 
            </form>
            <br />
            {/* Pass states to property */}

            <Table a={eng} b={urdu} c={math} d={total} e={perc}/>

        </div>
    



)
   

}












export default TextBox;