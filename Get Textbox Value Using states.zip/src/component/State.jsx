// import React, { useState } from "react";

// const Card = () => {
//   const [likeCount, setLikeCount] = useState(0);
//   const [dislikeCount, setDislikeCount] = useState(0);
//   const [loveCount, setLoveCount] = useState(0);

//   const handleLike = () => setLikeCount(likeCount + 1);
//   const handleDislike = () => setDislikeCount(dislikeCount + 1);
//   const handleLove = () => setLoveCount(loveCount + 1);
  

//   return (

//     <center>
//         <br /><br />

//     <div style={styles.card} style={{height:"65vh", width:"55vh", border:'solid 3px black',borderRadius:"2%"}}   >
//       <img
//         src="https://via.placeholder.com/300"alt="Sample"
//         style={styles.image}
//       />
//       <div style={styles.buttonContainer}>
//         <button style={styles.button} onClick={handleLike}>
//           👍 Like ({likeCount})
//         </button>
//         <button style={styles.button} onClick={handleDislike}>
//           👎 Dislike ({dislikeCount})
//         </button>
//         <button style={styles.button} onClick={handleLove}>
//           ❤️ Love ({loveCount})
//         </button>
//       </div>
//     </div>
//     </center>
//   );
// };

// const styles = {
//   card: {
//     width: "300px",
//     border: "1px solid #ddd",
//     borderRadius: "8px",
//     padding: "16px",
//     boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
//     textAlign: "center",
//   },
//   image: {
//     width: "100%",
//     borderRadius: "8px",
//   },
//   buttonContainer: {
//     display: "flex",
//     justifyContent: "space-around",
//     marginTop: "10px",
//   },
//   button: {
//     padding: "8px 16px",
//     border: "none",
//     borderRadius: "4px",
//     cursor: "pointer",
//     fontSize: "14px",
//   },
// };


// // import React from "react";
// // import Card from "./Card";

// // const App = () => {
// //   return (
// //     <div style={{ display: "flex", justifyContent: "center", marginTop: "20px" }}>
// //       <Card />
// //     </div>
// //   );
// // };

// // export default App;




// export default Card;














